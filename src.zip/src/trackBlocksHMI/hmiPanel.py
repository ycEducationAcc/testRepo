#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        hmiPanel.py
#
# Purpose:     This module is used to create different function panels.
#
# Author:      Yuancheng Liu
#
# Version:     v0.1.3
# Created:     2024/07/12
# Copyright:   Copyright (c) 2024 LiuYuancheng
# License:     MIT License 
#-----------------------------------------------------------------------------

""" Track block control HMI panel: 
    Panel PLC: PLC panel UI to show PLC input feedback state and the relay 
        connected to the related output pin.
    PanelBlockCtrl: Panel for operation to over ride the auto control of the
        retlated track block.(Junction block and station can not be override)
"""

import wx
import os

import trackBlockGobal as gv

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class PanelPLC(wx.Panel):
    """ PLC panel UI to show PLC input feedback state and the relay connected 
        to the related output pin.
    """
    def __init__(self, parent, name, ipAddr, icon=None, dInInfoList=None, dOutInfoList=None):
        """ Init the panel."""
        wx.Panel.__init__(self, parent)
        self.SetBackgroundColour(wx.Colour(200, 200, 200))
        # Init self paremeters
        self.plcName = name
        self.ipAddr = ipAddr
        self.regsNum = 16
        self.coilsNum = 8
        self.connectedFlg = False
        self.gpioInList = [0]*self.regsNum  # PLC GPIO input stuation list.
        self.gpioInLbList = []  # GPIO input device <id> label list.
        self.gpioOuList = [0]*self.coilsNum # PLC GPIO output situation list.
        self.gpioOuLbList = []  # GPIO output device <id> label list.
        self.dInInfoList = dInInfoList
        self.dOutInfoList = dOutInfoList
        # Init the UI.
        img = os.path.join(gv.IMG_FD, 'plcIcon.png')
        self.lbBmap = wx.Image(img, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        self.SetSizer(self.buidUISizer())
        #self.Layout() # must call the layout if the panel size is set to fix.

#--PanelPLC--------------------------------------------------------------------
    def buidUISizer(self):
        """ Build the UI and the return the wx.sizer. """
        mSizer = wx.BoxSizer(wx.VERTICAL) # main sizer
        flagsR = wx.LEFT
        mSizer.AddSpacer(5)
        # Row idx = 0 : set the basic PLC informaiton.
        titleSZ = self._buildTitleSizer()
        mSizer.Add(titleSZ, flag=flagsR, border=5)
        mSizer.AddSpacer(10)
        # Row idx = 1: set the GPIO and feed back of the PLC. 
        mSizer.Add(wx.StaticLine(self, wx.ID_ANY, size=(270, -1),
                                 style=wx.LI_HORIZONTAL), flag=flagsR, border=5)
        mSizer.AddSpacer(10)
        # - row line structure: Input indicator | output label | output button with current status.
        for i in range(self.regsNum):
            hsizer = wx.BoxSizer(wx.HORIZONTAL)
            # Col idx = 0: PLC digital in 
            if self.dInInfoList and i < len(self.dInInfoList):
                cfg = self.dInInfoList[i]
                lbtext = cfg['item']
                inputLb = wx.StaticText(self, label=lbtext.ljust(6))
                inputLb.SetBackgroundColour(cfg['color'])
                hsizer.Add(inputLb, flag=flagsR, border=5)
            else:
                inputLb = wx.StaticText(self, label='NoIO'.ljust(6))
                inputLb.SetBackgroundColour(wx.Colour('BLACK'))
                hsizer.Add(inputLb, flag=flagsR, border=5)
            # Col idx = 0: PLC input indicators.
            lbtext = " R_%H 0."+str(i)
            inputLb = wx.StaticText(self, label=lbtext.ljust(12))
            inputLb.SetBackgroundColour(wx.Colour(120, 120, 120))
            hsizer.Add(inputLb, flag=flagsR, border=5)
            self.gpioInLbList.append(inputLb)
            # Col idx =1: PLC output labels.
            hsizer.AddSpacer(5)
            if i < self.coilsNum:
                # Added the coils output info.
                hsizer.Add(wx.StaticText(self, label=str(
                    " %Q 0."+str(i)+':').ljust(12)), flag=flagsR, border=5)
                # Col idx =2: PLC output ON/OFF contorl buttons.
                #hsizer.AddSpacer(5)
                outputBt = wx.Button(self, label='OFF', size=(50, 17), name=self.plcName+':'+str(i))
                self.gpioOuLbList.append(outputBt)
                hsizer.Add(outputBt, flag=flagsR, border=5)
                # Add the digital output 
                if self.dOutInfoList and i < len(self.dOutInfoList):
                    cfg = self.dOutInfoList[i]
                    lbtext = cfg['item']
                    outputLb = wx.StaticText(self, label=lbtext.ljust(6))
                    outputLb.SetBackgroundColour(cfg['color'])
                    hsizer.Add(outputLb, flag=flagsR, border=5)
                else:
                    outputLb = wx.StaticText(self, label='NoIO'.ljust(6))
                    outputLb.SetBackgroundColour(wx.Colour('BLACK'))
                    hsizer.Add(outputLb, flag=flagsR, border=5)
            mSizer.Add(hsizer, flag=flagsR, border=5)
            mSizer.AddSpacer(3)
        return mSizer

#--PanelPLC--------------------------------------------------------------------
    def _buildTitleSizer(self):
        hsizer = wx.BoxSizer(wx.HORIZONTAL)
        flagsR = wx.LEFT
        btnSample = wx.StaticBitmap(self, -1, self.lbBmap, (0, 0), (self.lbBmap.GetWidth(), self.lbBmap.GetHeight()))
        hsizer.Add(btnSample, flag=flagsR, border=5)
        vsizer = wx.BoxSizer(wx.VERTICAL)
        self.nameLb = wx.StaticText(self, label=" PLC Name: ".ljust(15)+self.plcName)
        vsizer.Add(self.nameLb, flag=flagsR, border=5)
        self.ipaddrLb = wx.StaticText( self, label=" PLC IPaddr: ".ljust(15)+self.ipAddr)
        vsizer.Add(self.ipaddrLb, flag=flagsR, border=5)
        hbox0 = wx.BoxSizer(wx.HORIZONTAL)
        hbox0.Add(wx.StaticText(self, label=" Connection:".ljust(15)), flag=flagsR)
        self.connLb = wx.StaticText(self, label=' Connected ' if self.connectedFlg else ' Unconnected ')
        self.connLb.SetBackgroundColour( wx.Colour('GREEN') if self.connectedFlg else wx.Colour(120, 120, 120))
        hbox0.Add(self.connLb, flag=flagsR, border=5)
        vsizer.Add(hbox0, flag=flagsR, border=5)
        hsizer.Add(vsizer, flag=flagsR, border=5)
        return hsizer

#--PanelPLC--------------------------------------------------------------------
    def setConnection(self, state):
        """ Update the connection state on the UI."""
        self.connectedFlg = state
        self.connLb.SetLabel(' Connected ' if self.connectedFlg else ' Unconnected ')
        self.connLb.SetBackgroundColour(
            wx.Colour('GREEN') if self.connectedFlg else wx.Colour(120, 120, 120))
        self.Refresh(False)

#--PanelPLC--------------------------------------------------------------------
    def updateHoldingRegs(self, regList):
        """ Update the holding register's data and UI indicator's state if there 
            is new register chagne.
        """
        if regList is None or self.gpioInList == regList: return # no new update
        for idx in range(min(self.regsNum, len(regList))):
            status = regList[idx]
            if self.gpioInList[idx] != status:
                self.gpioInList[idx] = status
                self.gpioInLbList[idx].SetBackgroundColour(
                    wx.Colour('GREEN') if status else wx.Colour(120, 120, 120))

#--PanelPLC--------------------------------------------------------------------
    def updateCoils(self, coilsList):
        """ Update the coils data and UI indicator's state if there is new coils
            state chagne.
        """
        if coilsList is None or self.gpioOuList == coilsList: return  
        for idx in range(min(self.coilsNum, len(coilsList))):
            status = coilsList[idx]
            if self.gpioOuList[idx] != status:
                self.gpioOuList[idx] = status
                self.gpioOuLbList[idx].SetLabel('ON' if status else 'OFF')
                self.gpioOuLbList[idx].SetBackgroundColour(
                    wx.Colour('GREEN') if status else wx.Colour(253, 253, 253))

#--PanelPLC--------------------------------------------------------------------
    def updataPLCdata(self):
        if gv.idataMgr:
            plcdata =  gv.idataMgr.getPLCInfo(self.plcName)
            if plcdata:
                self.updateHoldingRegs(plcdata[0])
                self.updateCoils(plcdata[1])

#--PanelPLC--------------------------------------------------------------------
    def updateDisplay(self, updateFlag=None):
        """ Set/Update the display: if called as updateDisplay() the function will 
            update the panel, if called as updateDisplay(updateFlag=?) the function
            will set the self update flag.
        """
        self.Refresh(False)


#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class PanelBlockCtrl(wx.Panel):
    """ Block auto control over ride panel."""
    def __init__(self, parent, name):
        """ Init the panel."""
        wx.Panel.__init__(self, parent)
        self.SetBackgroundColour(wx.Colour(200, 200, 200))
        self.name = name
        self.SetSizer(self.buidUISizer())
        #self.Layout() # must call the layout if the panel size is set to fix.

    #-----------------------------------------------------------------------------
    def buidUISizer(self):
        mSizer = wx.BoxSizer(wx.HORIZONTAL) # main sizer
        flagsR = wx.LEFT
        mSizer.AddSpacer(5)
        weTrackBlkRange = (0, 6)
        weStationBLKRange = (0, 9)
        weccJuncBlkRange = (0, 8)
        vbox0 = self._buildCheckBoxList("WE-Track-Block[6]", "S-WE-TB", weTrackBlkRange)
        mSizer.Add(vbox0, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        vbox1 = self._buildCheckBoxList("WE-Station-Block[9]", "ST-WE-B", 
                                        weStationBLKRange, cbEabled=False)
        mSizer.Add(vbox1, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        vbox2 = self._buildCheckBoxList("WE-CC-Junction-Block[8]", "WE-CC-JB", 
                                        weccJuncBlkRange, cbEabled=False)
        mSizer.Add(vbox2, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        ccTrackBlkRange = (0, 6)
        ccStationBLKRange = (0, 6)
        vbox3 = self._buildCheckBoxList("CC-Track-Block[6]", "S-CC-TB", ccTrackBlkRange)
        mSizer.Add(vbox3, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        vbox4 = self._buildCheckBoxList("CC-Station-Block[6]", "ST-CC-B", ccStationBLKRange, cbEabled=False)
        mSizer.Add(vbox4, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        nsccJuncBlkRange = (0, 4)
        nsTrackBlkRange = (0, 3)
        nsStationBlkRange = (0, 6)
        vbox5 = self._buildCheckBoxList("NS-CC-Junction-Block[4]", "NS-CC-JB", 
                                        nsccJuncBlkRange, cbEabled=False)
        mSizer.Add(vbox5, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        vbox6 = self._buildCheckBoxList("NS-Track-Block[3]", "S-CC-TB", nsTrackBlkRange)
        mSizer.Add(vbox6, flag=flagsR, border=5)
        mSizer.AddSpacer(5)
        vbox7 = self._buildCheckBoxList("NS-Station-Block[6]", "ST-CC-B", 
                                        nsStationBlkRange, cbEabled=False)
        mSizer.Add(vbox7, flag=flagsR, border=5)
        mSizer.AddSpacer(10)
        return mSizer

    #-----------------------------------------------------------------------------
    def _buildCheckBoxList(self, labelStr, tagStr, rangeTuple, cbEabled=True):
        flagsR = wx.LEFT
        vbox0 = wx.BoxSizer(wx.VERTICAL)
        vbox0.AddSpacer(10)
        vbox0.Add(wx.StaticText(self, label=str(labelStr)), flag=flagsR, border=5)
        vbox0.AddSpacer(10)
        for i in range(rangeTuple[0], rangeTuple[1]):
            blkCB = wx.CheckBox(self, label="%s %s" %(tagStr, str(i).rjust(2,'0')))
            blkCB.SetValue(True)
            blkCB.Enable(cbEabled)
            vbox0.Add(blkCB, flag=flagsR, border=5)
            vbox0.AddSpacer(10)
        return vbox0

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
def main():
    """ Main function used for local test debug panel. """

    print('Test Case start: type in the panel you want to check:')
    print('0 - PanelImge')
    print('1 - PanelCtrl')
    #pyin = str(input()).rstrip('\n')
    #testPanelIdx = int(pyin)
    testPanelIdx = 0    # change this parameter for you to test.
    print("[%s]" %str(testPanelIdx))
    app = wx.App()
    mainFrame = wx.Frame(gv.iMainFrame, -1, 'Debug Panel',
                         pos=(300, 300), size=(640, 480), style=wx.DEFAULT_FRAME_STYLE)
    if testPanelIdx == 0:
        testPanel = PanelPLC(mainFrame, 'plc1', '127.0.0.1:502')
    elif testPanelIdx == 1:
        testPanel = PanelBlockCtrl(mainFrame)
    mainFrame.Show()
    app.MainLoop()

if __name__ == "__main__":
    main()



