#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        TrackBlockHMIRun.py
#
# Purpose:     This module is the main wx-frame of railway track block signaling
#              system's human machine interface which used by the HQ operator
#              to monitor and manage the track block.
#              
# Author:      Yuancheng Liu
#
# Version:     v0.1.3
# Created:     2024/06/03
# Copyright:   Copyright (c) 2024 LiuYuancheng
# License:     MIT License    
#-----------------------------------------------------------------------------
"""
    System Design Purpose: 
        We want to create a HMI connect to the PLC to fetch the track fixed block
        Automatic Train Protection (ATP) sensor and signal state then visualize the 
        data. It also provide the sensor over ride function for the HQ operator to 
        manually set the sensor state to process some emergency situation.
"""
import os
import time
import wx

import trackBlockGobal as gv
import hmiPanel as pnlFunction
import hmiMapMgr as mapMgr
import hmiPanelMap as pnlMap
import scadaPlcDataMgr as dataMgr

FRAME_SIZE = (1800, 1030) # default UI frame size.
HELP_MSG="""
If there is any bug, please contact:
 - Author:      Yuancheng Liu 
 - Email:       liu_yuan_cheng@hotmail.com 
 - Created:     2024/06/03 
 - GitHub Link: https://github.com/LiuYuancheng/Railway_IT_OT_System_Cyber_Security_Platform
"""

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class UIFrame(wx.Frame):
    """ Main UI frame window."""

    def __init__(self, parent, id, title):
        """ Init the UI and parameters """
        wx.Frame.__init__(self, parent, id, title, size=FRAME_SIZE)
        self.SetBackgroundColour(wx.Colour(200, 210, 200))
        self.SetIcon(wx.Icon(gv.ICO_PATH))
        self._initGlobals()
        # Build UI sizer
        self._buildMenuBar()
        self.SetSizer(self._buidUISizer())
        self.statusbar = self.CreateStatusBar(1)
        self.statusbar.SetStatusText('Test mode: %s' % str(gv.TEST_MD))
        # Init the local parameters:
        self.updateLock = False
        # Set the periodic call back
        self.updatePlcConIndicator()
        self.lastPeriodicTime = time.time()
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.periodic)
        self.timer.Start(gv.PERIODIC)  # every 500 ms
        self.Bind(wx.EVT_CLOSE, self.onClose)
        gv.gDebugPrint("Track Blocks HMI Inited, test mode: %s" % str(gv.TEST_MD), 
                       logType=gv.LOG_INFO)

#-----------------------------------------------------------------------------
    def _initGlobals(self):
        """ Init the global parameters used only by this module."""
        gv.gTrackConfig['weline'] = {'id': 'weline',
                                    # weline junction sensors connected to holding register idx on PLC-08/09
                                    'sensorIdx': (0, 12), 'signalIdx': (0, 6), 
                                    'color': wx.Colour(52, 169, 129), 
                                    'icon': 'welabel.png'}
        
        gv.gTrackConfig['nsline'] = {'id': 'nsline',
                                    # nsline junction sensors connected to holding register idx on PLC-00/01/02
                                    'sensorIdx': (12, 18), 'signalIdx': (6, 9),
                                    'color': wx.Colour(233, 0, 97), 
                                    'icon': 'nslabel.png'}
        
        gv.gTrackConfig['ccline'] = {'id': 'ccline', 
                                    # ccline junction sensors connected to holding register idx on PLC-00/01/02
                                    'sensorIdx': (18, 30), 'signalIdx': (9, 15),
                                    'color': wx.Colour(255, 136, 0), 
                                    'icon': 'cclabel.png'}
        # Init the display manager
        gv.iMapMgr = mapMgr.MapMgr(self)
        # Init the data manager if we are under real mode.(need to connect to PLC module.)
        if not gv.TEST_MD: gv.idataMgr = dataMgr.DataManager(self, gv.gPlcInfo)

#-----------------------------------------------------------------------------
    def _initElectricalLbs(self):
        """ Init the plc 16 electrical-input and 8 electrical-output labels."""
        self.digitalInLBList = {}
        self.digitalOutLBList = {}
        welineColor = gv.gTrackConfig['weline']['color']
        nslineColor = gv.gTrackConfig['nsline']['color']
        cclineColor = gv.gTrackConfig['ccline']['color']
        
        # init the PLC-08 16 electrical-input sensor label 
        self.digitalInLBList['PLC-08'] = []
        welineSenIdx08 = (0,1,17,3,5,6,18,7,19,11,20,13)
        for i in welineSenIdx08:
            data = {'item': 'wes'+str(i).zfill(2), 'color': welineColor}
            self.digitalInLBList['PLC-08'].append(data)
        nslineSenIdx08 = (8,1,9,2)
        for i in nslineSenIdx08:
            data = {'item': 'nss'+str(i).zfill(2), 'color': nslineColor}
            self.digitalInLBList['PLC-08'].append(data)
        
        # init the PLC-08 8 electrical-output signal label 
        self.digitalOutLBList['PLC-08'] = []
        welineSigIdx08 = (8,9,10,11,12,13)
        for i in welineSigIdx08:
            data = {'item': 'Swe'+str(i).zfill(2), 'color': welineColor}
            self.digitalOutLBList['PLC-08'].append(data)
        nslineSigIdx08 = (4,5)
        for i in nslineSigIdx08:
            data = {'item': 'Sns'+str(i).zfill(2), 'color': nslineColor}
            self.digitalOutLBList['PLC-08'].append(data)
        
        # init the PLC-09 14 electrical-input sensor label 
        self.digitalInLBList['PLC-09'] = []
        nslineSenIdx09 = (10, 4)
        for i in nslineSenIdx09:
            data = {'item': 'nss'+str(i).zfill(2), 'color': nslineColor}
            self.digitalInLBList['PLC-09'].append(data)
        cclineSenIdx09 =  (14,0,15,2,16,4,17,6,18,8,12,13)
        for i in cclineSenIdx09:
            data = {'item': 'ccs'+str(i).zfill(2), 'color': cclineColor}
            self.digitalInLBList['PLC-09'].append(data)
        
        # init the PLC-09 7 electrical-output signal label 
        self.digitalOutLBList['PLC-09'] = []
        nslineSigIdx09 = (6,)
        for i in nslineSigIdx09:
            data = {'item': 'Sns'+str(i).zfill(2), 'color': nslineColor}
            self.digitalOutLBList['PLC-09'].append(data)
        cclineSigIdx09 = (7, 8, 9, 10, 11, 12)
        for i in cclineSigIdx09:
            data = {'item': 'Scc'+str(i).zfill(2), 'color': cclineColor}
            self.digitalOutLBList['PLC-09'].append(data)

#-----------------------------------------------------------------------------
    def _buildMenuBar(self):
        """ Creat the top function menu bar."""
        menubar = wx.MenuBar()
        # Add the config menu
        pass
        # Add the about menu.
        helpMenu = wx.Menu()
        aboutItem = wx.MenuItem(helpMenu, 200, text="Help", kind=wx.ITEM_NORMAL)
        helpMenu.Append(aboutItem)
        self.Bind(wx.EVT_MENU, self.onHelp, aboutItem)
        menubar.Append(helpMenu, '&About')
        self.SetMenuBar(menubar)

#-----------------------------------------------------------------------------
    def _buidUISizer(self):
        """ Build the main UI Sizer. """
        flagsL = wx.LEFT
        mSizer = wx.BoxSizer(wx.VERTICAL)
        mSizer.AddSpacer(5)
        # Added the map panel.
        font = wx.Font(12, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
        label = wx.StaticText(self, label=" Railway Tracks Fixed Blocking Automatic Train Protection (ATP) HMI")
        label.SetFont(font)
        mSizer.Add(label, flag=flagsL, border=2)
        mSizer.AddSpacer(10)
        gv.iMapPanel = pnlMap.PanelMap(self)
        mSizer.Add(gv.iMapPanel, flag=wx.CENTER, border=2)
        mSizer.AddSpacer(10)
        mSizer.Add(wx.StaticLine(self, wx.ID_ANY, size=(1790, -1),
                                style=wx.LI_HORIZONTAL), flag=flagsL, border=5)
        mSizer.AddSpacer(5)
        # Added the bottum box sizeer
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        hbox1.AddSpacer(10)

        # Add the block override panels
        vbox0 = wx.BoxSizer(wx.VERTICAL)
        box0label = wx.StaticText(self, label="Track Block Singal Override Control")
        box0label.SetFont(font)
        vbox0.Add(box0label, flag=wx.CENTER, border=2)
        img = os.path.join(gv.IMG_FD, 'blklabel.png')
        png = wx.Image(img, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        sublabel = wx.StaticBitmap(self, -1, png, (10, 5), (png.GetWidth(), png.GetHeight()))
        vbox0.Add(sublabel, flag=wx.CENTER, border=2)
        self.blckCtrlPnl = pnlFunction.PanelBlockCtrl(self, 'block over ride')
        vbox0.Add(self.blckCtrlPnl, flag=wx.CENTER, border=2)
        hbox1.Add(vbox0, flag=flagsL, border=2)

        hbox1.AddSpacer(10)
        hbox1.Add(wx.StaticLine(self, wx.ID_ANY, size=(-1, 400),
                        style=wx.LI_VERTICAL), flag=flagsL, border=5)

        # Add the PLC display panels
        self.plcPnls = {}
        self._initElectricalLbs()
        # junction sensor-signal plc sizer.
        signalSz = self._buildPlcPnlsSizer("PLC Monitor [Track Blocks Sensor-Signal]", 
                                           ('PLC-08', 'PLC-09'))
        hbox1.Add(signalSz, flag=flagsL, border=2)
        
        hbox1.AddSpacer(10)
        hbox1.Add(wx.StaticLine(self, wx.ID_ANY, size=(-1, 400),
                        style=wx.LI_VERTICAL), flag=flagsL, border=5)
        mSizer.Add(hbox1, flag=flagsL, border=2)
        return mSizer

#-----------------------------------------------------------------------------
    def _buildPlcPnlsSizer(self, PanelTitle, panelKeySeq):
        """Build PLC panel UI sizer. """
        flagsL = wx.LEFT
        font = wx.Font(12, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
        vSizer = wx.BoxSizer(wx.VERTICAL)
        label = wx.StaticText(self, label=PanelTitle)
        label.SetFont(font)
        vSizer.Add(label, flag=wx.CENTER, border=2)
        vSizer.AddSpacer(5)
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        for key in panelKeySeq:
            hbox1.AddSpacer(10)
            panelInfo = gv.gPlcPnlInfo[key]
            ipaddr = panelInfo['ipaddress'] + ' : ' + str(panelInfo['port'])
            dInInfoList =  self.digitalInLBList[key] if key in self.digitalInLBList.keys() else None
            dOutInfoList = self.digitalOutLBList[key] if key in self.digitalOutLBList.keys() else None
            self.plcPnls[key] = pnlFunction.PanelPLC(self, panelInfo['label'], ipaddr, 
                                                     dInInfoList=dInInfoList,
                                                     dOutInfoList=dOutInfoList)
            hbox1.Add(self.plcPnls[key], flag=flagsL, border=2)
        vSizer.Add(hbox1, flag=flagsL, border=2)
        return vSizer
        
#--UIFrame---------------------------------------------------------------------
    def periodic(self, event):
        """ Call back every periodic time."""
        now = time.time()
        if (not self.updateLock) and now - self.lastPeriodicTime >= gv.gUpdateRate:
            print("main frame update at %s" % str(now))
            self.lastPeriodicTime = now
            if not gv.TEST_MD:
                if gv.idataMgr: gv.idataMgr.periodic(now)
                self.updatePlcConIndicator()
                self.updatePlcPanels()
                self.updateMapTrackBlockData()
                #self.updateMapStationData()
            gv.iMapPanel.periodic(now)

#-----------------------------------------------------------------------------
    def updatePlcConIndicator(self):
        """ Update the PLC's state panel connection state."""
        if gv.idataMgr is None: return False
        for key in self.plcPnls.keys():
            plcID = gv.gPlcPnlInfo[key]['tgt']
            self.plcPnls[key].setConnection(gv.idataMgr.getConntionState(plcID))
        return True

#-----------------------------------------------------------------------------
    def updatePlcPanels(self):
        if gv.idataMgr is None: return False
        # update the PLC display panel
        for key in self.plcPnls.keys():
            # update the holding registers
            tgtPlcID = gv.gPlcPnlInfo[key]['tgt']
            rsIdx, reIdx = gv.gPlcPnlInfo[key]['hRegsInfo']
            registList = gv.idataMgr.getPlcHRegsData(tgtPlcID, rsIdx, reIdx)
            # print(registList)
            self.plcPnls[key].updateHoldingRegs(registList)
            csIdx, ceIdx = gv.gPlcPnlInfo[key]['coilsInfo']
            coilsList = gv.idataMgr.getPlcCoilsData(tgtPlcID, csIdx, ceIdx)
            # print(coilsList)
            self.plcPnls[key].updateCoils(coilsList)
            self.plcPnls[key].updateDisplay()

#-----------------------------------------------------------------------------
    def updateMapTrackBlockData(self):
        if gv.idataMgr is None: return False
        # update all the map junction sensor and signals
        signalTgtPlcID = 'PLC-08'
        for key in gv.gTrackConfig.keys():
            rsIdx, reIdx = gv.gTrackConfig[key]['sensorIdx']
            registList = gv.idataMgr.getPlcHRegsData(signalTgtPlcID, rsIdx, reIdx)
            #print(key)
            gv.iMapMgr.setSensors(key, registList)
            csIdx, ceIdx = gv.gTrackConfig[key]['signalIdx']
            coilsList = gv.idataMgr.getPlcCoilsData(signalTgtPlcID, csIdx, ceIdx)
            gv.iMapMgr.setSingals(key, coilsList)

#-----------------------------------------------------------------------------
    def updateMapStationData(self):
        if gv.idataMgr is None: return False
        # update all the station sensros and signals
        tgtPlcID = 'PLC-03'
        for key in gv.gTrackConfig.keys():
            rsIdx, reIdx = gv.gTrackConfig[key]['stationSensorIdx']
            registList = gv.idataMgr.getPlcHRegsData(tgtPlcID, rsIdx, reIdx)
            #print(key)
            gv.iMapMgr.setStationsSensors(key, registList)
            csIdx, ceIdx = gv.gTrackConfig[key]['stationSignalIdx']
            coilsList = gv.idataMgr.getPlcCoilsData(tgtPlcID, csIdx, ceIdx)
            gv.iMapMgr.setStationsSignals(key, coilsList)

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
    def onHelp(self, event):
        """ Pop-up the Help information window. """
        wx.MessageBox(HELP_MSG, 'Help', wx.OK)
        
#-----------------------------------------------------------------------------
    def onClose(self, evt):
        """ Pop up the confirm close dialog when the user close the UI from 'x'."""
        try:
            fCanVeto = evt.CanVeto()
            if fCanVeto:
                confirm = wx.MessageDialog(self, 'Click OK to close this program, or click Cancel to ignore close request',
                                            'Quit request', wx.OK | wx.CANCEL| wx.ICON_WARNING).ShowModal()
                if confirm == wx.ID_CANCEL:
                    evt.Veto(True)
                    return
                if gv.idataMgr: gv.idataMgr.stop()
                self.timer.Stop()
                self.Destroy()
        except Exception as err:
            gv.gDebugPrint("Error to close the UI: %s" %str(err), logType=gv.LOG_ERR)

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class MyApp(wx.App):
    def OnInit(self):
        gv.iMainFrame = UIFrame(None, -1, gv.UI_TITLE)
        gv.iMainFrame.Show(True)
        return True

#-----------------------------------------------------------------------------
if __name__ == '__main__':
    app = MyApp(0)
    app.MainLoop()
