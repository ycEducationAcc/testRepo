#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        hmiMapMgr.py
#
# Purpose:     The management module to control all the components on the map 
#              and update the components state. 
# 
# Author:      Yuancheng Liu
#
# Version:     v0.1.3
# Created:     2024/07/19
# Copyright:   Copyright (c) 2024 LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------

import json
import trackBlockGobal as gv
from collections import OrderedDict

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------

class AgentSensors(object):
    """ The sensors set to show the sensors detection state."""
    def __init__(self, parent, id, senIdList=None, posList=None):
        self.parent = parent
        self.id = id
        self.senIdList = senIdList
        self.sensorsCount = 0 if posList is None else len(posList)
        self.sensorsPosList = [] if posList is None else posList
        self.sensorsStateList = [0]*self.sensorsCount

    def addOneSensor(self, pos):
        self.sensorsPosList.append(pos)
        self.sensorsCount += 1
        self.sensorsStateList.append(0)
    
    def updateSensorState(self, idx, state):
        if idx < self.sensorsCount:
            self.sensorsStateList[idx] = state

    def updateSensorsState(self, statList):
        if statList is None: return
        print("update sensor: %s, in: %s, %s " %(str(self.id), str(self.sensorsCount), str(len(statList))))
        if len(statList) == self.sensorsCount:
            self.sensorsStateList = statList
#-----------------------------------------------------------------------------
# Init all the get() function here:
    def getID(self):
        return self.id
    
    def getSenIdList(self):
        return self.senIdList

    def getSensorsCount(self):
        return self.sensorsCount

    def getSensorPos(self):
        return self.sensorsPosList

    def getSensorsState(self):
        return self.sensorsStateList

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class AgentSignal(object):
    """ The signal agent."""
    def __init__(self, parent, id, pos) -> None:
        self.parent = parent
        self.id = id
        self.pos = pos
        self.state = False
        self.triggerOnPosList = []
        self.triggerOffPosList = []
    
    def addTGonPos(self, pos):
        self.triggerOnPosList.append(pos)

    def addTFoffPos(self, pos):
        self.triggerOffPosList.append(pos)

#-----------------------------------------------------------------------------
# Init all the get() function here:
    def getID(self):
        return self.id
    
    def getState(self):
        return self.state

    def getPos(self):
        return self.pos
    
    def getTGonPos(self):
        return self.triggerOnPosList
    
    def getTGoffPos(self):
        return self.triggerOffPosList
    
    def setState(self, state):
        self.state = state

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class AgentStation(object):
    """ The station agent."""
    def __init__(self, parent, id, pos, labelLayout=gv.LAY_D) -> None:
        self.parent = parent
        self.id = id 
        self.pos = pos 
        self.sensorState = False    # station sensor state. 
        self.signalState = False    # station singal state.
        self.labelLayout = labelLayout

#-----------------------------------------------------------------------------
# Init all the get() function here:
    def getID(self):
        return self.id
    
    def getPos(self):
        return self.pos

    def getSensorState(self):
        return self.sensorState
    
    def getSignalState(self):
        return self.signalState

    def getlabelLayout(self):
        return self.labelLayout

#-----------------------------------------------------------------------------
# Init all the set() function here:
    def setSensorState(self, state):
        self.sensorState = state

    def setSignalState(self, state):
        self.signalState = state

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class MapMgr(object):
    """ Map manager to init/control differet elements state on the map."""
    def __init__(self, parent):
        """ Init all the elements on the map. All the parameters are public to 
            other module.
        """
        self.sensors = OrderedDict()
        self.signals = OrderedDict()
        self.stations = OrderedDict()
        self.junctions = OrderedDict()
        self._initSensors()
        self._initSignals()
        self._initStations()
        self._initJunctionBlk()

#-----------------------------------------------------------------------------
    def _initSensors(self):
        """ Init all the sensors location on track."""
        # weline (top)
        x = 120
        y = 100
        sensorPos_we = [
            (x+80*0+20, y),
            (x+80*0+80, y),
            (x+80*2+20, y),
            (x+80*2+80, y),
            (x+80*4+20, y),
            (x+80*4+80, y),
            (x+80*6+20, y),
            (x+80*6+80, y),
            (x+80*12+20, y),
            (x+80*12+80, y),
            (x+80*14+20, y),
            (x+80*14+80, y),
        ]
        self.sensors['weline'] = AgentSensors(self, 'we', 
                                              senIdList=(0,1,17,3,5,6,18,7,19,11,20,13))
        for pos in sensorPos_we:
            self.sensors['weline'].addOneSensor(pos)
            
        # ccline (mid)
        x = 160
        y += 160
        sensorPos_cc = [
            (x+300*0+30, y),
            (x+300*0+30+80, y),
            (x+300*0+30+160, y),
            (x+300*0+30+240, y),
            (x+300*1+30+160, y),
            (x+300*1+30+240, y),
            (x+300*2+30, y),
            (x+300*2+30+80, y),
            (x+300*2+30+160, y),
            (x+300*2+30+240, y),
            (x+300*3+30+160, y),
            (x+300*3+30+240, y),
        ]

        self.sensors['ccline'] = AgentSensors(self, 'cc', 
                                              senIdList=(14,0,15,2,16,4,17,6,18,8,12,13))
        for pos in sensorPos_cc:
            self.sensors['ccline'].addOneSensor(pos)
        # nsline (btm)
        x = 250
        y+= 160
        sensorPos_ns = [
            (x+250*0+30, y),
            (x+250*0+30+70, y),
            (x+250*1+30, y),
            (x+250*1+30+70, y),
            (x+250*3+30, y),
            (x+250*3+30+70, y),
        ]
        self.sensors['nsline'] = AgentSensors(self, 'ns', 
                                              senIdList=(8,1,9,2,10,4))
        for pos in sensorPos_ns:
            self.sensors['nsline'].addOneSensor(pos)

#-----------------------------------------------------------------------------
    def _builSignalList(self, configDict):
        signals = []
        for signalInfo in configDict:
            signal = AgentSignal(self, signalInfo['id'], signalInfo['pos'])
            sPosList = self.getSensors(trackID=signalInfo['tiggerS']).getSensorPos()
            for idx in signalInfo['onIdx']:
                signal.addTGonPos(sPosList[idx])
            for idx in signalInfo['offIdx']:
                signal.addTFoffPos(sPosList[idx])
            signals.append(signal)
        return signals

#-----------------------------------------------------------------------------
    def _initSignals(self):
        """ Init all the signals location on track."""
        # weline (top)
        x = 120
        y = 100
        key = 'weline'
        trackSignalConfig_we = [
            {'id': 'WE-TB00', 'pos':(x+80*0+50, y), 'tiggerS': 'weline', 'onIdx':(0,), 'offIdx':(1,) },
            {'id': 'WE-TB01', 'pos':(x+80*2+50, y), 'tiggerS': 'weline', 'onIdx':(2,), 'offIdx':(3,) },
            {'id': 'WE-TB02', 'pos':(x+80*4+50, y), 'tiggerS': 'weline', 'onIdx':(4,), 'offIdx':(5,) },
            {'id': 'WE-TB03', 'pos':(x+80*6+50, y), 'tiggerS': 'weline', 'onIdx':(6,), 'offIdx':(7,) },
            {'id': 'WE-TB04', 'pos':(x+80*12+50, y), 'tiggerS': 'weline', 'onIdx':(8,), 'offIdx':(9,) },
            {'id': 'WE-TB05', 'pos':(x+80*14+50, y), 'tiggerS': 'weline', 'onIdx':(10,), 'offIdx':(11,) }
        ]
        self.signals[key] = self._builSignalList(trackSignalConfig_we)
         
        # ccline (mid)
        x = 160
        y += 160
        trackSignalConfig_cc = [
            {'id': 'CC-TB00', 'pos':(x+300*0+70, y), 'tiggerS': 'ccline', 'onIdx':(0,), 'offIdx':(1,) },
            {'id': 'CC-TB01', 'pos':(x+300*0+230, y), 'tiggerS': 'ccline', 'onIdx':(2,), 'offIdx':(3,) },
            {'id': 'CC-TB02', 'pos':(x+300*1+230, y), 'tiggerS': 'ccline', 'onIdx':(4,), 'offIdx':(5,) },
            {'id': 'CC-TB03', 'pos':(x+300*2+70, y),  'tiggerS': 'ccline', 'onIdx':(6,), 'offIdx':(7,) },
            {'id': 'CC-TB04', 'pos':(x+300*2+230, y),  'tiggerS': 'ccline', 'onIdx':(8,), 'offIdx':(9,) },
            {'id': 'CC-TB05', 'pos':(x+300*3+230, y),  'tiggerS': 'ccline', 'onIdx':(10,), 'offIdx':(11,) }
        ]
        key = 'ccline'
        self.signals[key] = self._builSignalList(trackSignalConfig_cc)

        # nsline (btm)
        x = 250
        y += 160
        trackSignalConfig_ns = [
            {'id': 'NS-TB00', 'pos':(x+250*0+70, y), 'tiggerS': 'nsline', 'onIdx':(0,), 'offIdx':(1,) },
            {'id': 'NS-TB01', 'pos':(x+250*1+70, y), 'tiggerS': 'nsline', 'onIdx':(2,), 'offIdx':(3,) },
            {'id': 'NS-TB02', 'pos':(x+250*3+70, y), 'tiggerS': 'nsline', 'onIdx':(4,), 'offIdx':(5,) }
        ]
        key = 'nsline'
        self.signals[key] = self._builSignalList(trackSignalConfig_ns)

#-----------------------------------------------------------------------------
    def _initStations(self):
        """ Init all the station location on track."""
        # weline (top)
        x = 120
        y = 100
        key = 'weline'
        # load the station name config file
        trackStation_we = None 
        try:
            with open(gv.gWeStationFile, 'r') as f:
                weStataionNameList = json.load(f)
                trackStation_we = [
                        {'id': weStataionNameList[0]['id'], 'pos': (x+80*0, y), 'layout': gv.LAY_D},
                        {'id': weStataionNameList[1]['id'], 'pos': (x+80*2, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[2]['id'], 'pos': (x+80*4, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[3]['id'], 'pos': (x+80*6, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[4]['id'], 'pos': (x+80*8, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[5]['id'], 'pos': (x+80*10, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[6]['id'], 'pos': (x+80*12, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[7]['id'], 'pos': (x+80*14, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[8]['id'], 'pos': (x+80*16, y), 'layout': gv.LAY_U},
                        {'id': weStataionNameList[9]['id'], 'pos': (x+80*18, y), 'layout': gv.LAY_U}
                    ]
        except Exception as error:
            gv.gDebugPrint("Error to load the station config file: %s" % error)
            # Use the default setting.
            trackStation_we = [
                        {'id': 'Tuas_Link',     'pos': (x+80*0, y),    'layout': gv.LAY_D},
                        {'id': 'Jurong_East',   'pos': (x+80*2, y),    'layout': gv.LAY_U},
                        {'id': 'Outram_Park',   'pos': (x+80*4, y),    'layout': gv.LAY_U},
                        {'id': 'City_Hall',     'pos': (x+80*6, y),    'layout': gv.LAY_U},
                        {'id': 'Paya_Lebar',    'pos': (x+80*8, y),    'layout': gv.LAY_U},
                        {'id': 'Changi_Airport','pos': (x+80*10, y),   'layout': gv.LAY_U},
                        {'id': 'Lavender',      'pos': (x+80*12, y),   'layout': gv.LAY_U},
                        {'id': 'Raffles_Place', 'pos': (x+80*14, y),   'layout': gv.LAY_U},
                        {'id': 'Clementi',      'pos': (x+80*16, y),   'layout': gv.LAY_U},
                        {'id': 'Boon_Lay',      'pos': (x+80*18, y),   'layout': gv.LAY_U}
                    ]
        
        self.stations[key] = []
        for stationInfo in trackStation_we:
            station = AgentStation(self, stationInfo['id'], stationInfo['pos'], labelLayout=stationInfo['layout'])
            self.stations[key].append(station)
        # ccline (mid)
        x = 160
        y += 160
        key = 'ccline'
        trackStation_cc = None
        try:
            with open(gv.gCcStationFile, 'r') as f:
                ccStataionNameList = json.load(f)
                trackStation_cc = [
                        {'id': ccStataionNameList[0]['id'], 'pos': (x+300*0, y),   'layout': gv.LAY_D},
                        {'id': ccStataionNameList[1]['id'], 'pos': (x+300*1, y),   'layout': gv.LAY_D},
                        {'id': ccStataionNameList[2]['id'], 'pos': (x+300*2, y),    'layout': gv.LAY_D},
                        {'id': ccStataionNameList[3]['id'], 'pos': (x+300*3, y),    'layout': gv.LAY_D},
                        {'id': ccStataionNameList[4]['id'], 'pos': (x+300*4, y),    'layout': gv.LAY_D},
                        {'id': ccStataionNameList[5]['id'], 'pos': (x+300*5, y),    'layout': gv.LAY_D}
                    ]
        except Exception as error:
            gv.gDebugPrint("Error to load the station config file: %s" % error)
            trackStation_cc = [
                    {'id': 'Buona_Vista',   'pos': (x+300*0, y),   'layout': gv.LAY_D},
                    {'id': 'Farrer_Road',   'pos': (x+300*1, y),   'layout': gv.LAY_D},
                    {'id': 'Serangoon',     'pos': (x+300*2, y),    'layout': gv.LAY_D},
                    {'id': 'Nicoll_Highway','pos': (x+300*3, y),    'layout': gv.LAY_D},
                    {'id': 'Bayfront',      'pos': (x+300*4, y),    'layout': gv.LAY_D},
                    {'id': 'Harbourfront',  'pos': (x+300*5, y),    'layout': gv.LAY_D}
                ]
        self.stations[key] = []
        for stationInfo in trackStation_cc:
            station = AgentStation(self, stationInfo['id'], stationInfo['pos'], labelLayout=stationInfo['layout'])
            self.stations[key].append(station)
        # nsline (btm)
        x = 250
        y += 160
        key = 'nsline'
        trackStation_ns = None 
        try:
            with open(gv.gNsStationFile, 'r') as f:
                nsStataionNameList = json.load(f)
                trackStation_ns = [
                        {'id': nsStataionNameList[0]['id'], 'pos': (x+250*0, y), 'layout': gv.LAY_D},
                        {'id': nsStataionNameList[1]['id'], 'pos': (x+250*1, y), 'layout': gv.LAY_D},
                        {'id': nsStataionNameList[2]['id'], 'pos': (x+250*2, y), 'layout': gv.LAY_D},
                        {'id': nsStataionNameList[3]['id'], 'pos': (x+250*3, y), 'layout': gv.LAY_D},
                        {'id': nsStataionNameList[4]['id'], 'pos': (x+250*4, y), 'layout': gv.LAY_D},
                        {'id': nsStataionNameList[5]['id'], 'pos': (x+250*5, y), 'layout': gv.LAY_D}
                    ]
        except Exception as error:
            gv.gDebugPrint("Error to load the station config file: %s" % error)
            trackStation_ns = [
                    {'id': 'Jurong_East',   'pos': (x+250*0, y),    'layout': gv.LAY_D},
                    {'id': 'Woodlands',     'pos': (x+250*1, y),    'layout': gv.LAY_U},
                    {'id': 'Yishun',        'pos': (x+250*2, y),    'layout': gv.LAY_D},
                    {'id': 'Orchard',       'pos': (x+250*3, y),    'layout': gv.LAY_U},
                    {'id': 'City_Hall',     'pos': (x+250*4, y),    'layout': gv.LAY_D},
                    {'id': 'Bishan',        'pos': (x+250*5, y),    'layout': gv.LAY_D}
                ]
        self.stations[key] = []
        for stationInfo in trackStation_ns:
            station = AgentStation(self, stationInfo['id'], stationInfo['pos'], labelLayout=stationInfo['layout'])
            self.stations[key].append(station)

#-----------------------------------------------------------------------------
    def _initJunctionBlk(self):
        """ Init all the junction block on the map. """
        # junction block for WE line
        x = 120
        y = 100
        junctionBlocks_we = [
            {'id': 'WE-CC-JB00', 'pos': (x+80*0+80, y)},
            {'id': 'WE-CC-JB01', 'pos': (x+80*2+80, y)},
            {'id': 'WE-CC-JB02', 'pos': (x+80*4+80, y)},
            {'id': 'WE-CC-JB03', 'pos': (x+80*8+80, y)},
            {'id': 'WE-CC-JB04', 'pos': (x+80*10+80, y)},
            {'id': 'WE-CC-JB05', 'pos': (x+80*12+80, y)},
            {'id': 'WE-CC-JB06', 'pos': (x+80*14+80, y)},
            {'id': 'WE-CC-JB07', 'pos': (x+80*16+80, y)},
            {'id': 'WE-CC-JB08', 'pos': (x+80*18+80, y)},
        ]
        self.junctions['weline'] = junctionBlocks_we
        
        # junction block for NS line 
        x = 250
        y = 420
        junctionBlocks_ns = [
            {'id': 'NS-CC-JB00', 'pos': (x+250*0+140, y)},
            {'id': 'NS-CC-JB01', 'pos': (x+250*2+140, y)},
            {'id': 'NS-CC-JB02', 'pos': (x+250*4+140, y)},
            {'id': 'NS-CC-JB03', 'pos': (x+250*5+140, y)},
        ]
        self.junctions['nsline'] = junctionBlocks_ns


#-----------------------------------------------------------------------------
# Init all the get() function here:
    def getSensors(self, trackID=None):
        if trackID and trackID in self.sensors.keys(): return self.sensors[trackID]
        return self.sensors

    def getSignals(self, trackID=None):
        if trackID and trackID in self.signals.keys(): return self.signals[trackID]
        return self.signals
    
    def getStations(self, trackID=None):
        if trackID and trackID in self.stations.keys(): return self.stations[trackID]
        return self.stations

    def getJunctions(self):
        return self.junctions

#-----------------------------------------------------------------------------
# Init all the set() function here:
    def setSensors(self, trackID, stateList):
        self.sensors[trackID].updateSensorsState(stateList)

    def setSingals(self, trackID, stateList):
        if trackID is None or stateList is None: return
        if len(stateList) <= len(self.signals[trackID]):
            for i, state in enumerate(stateList):
                self.signals[trackID][i].setState(state)

    def setStationsSensors(self, trackID, stateList):
        if trackID is None or stateList is None: return
        if trackID in self.stations.keys() and len(stateList) <= len(self.stations[trackID]):
            for i, state in enumerate(stateList):
                self.stations[trackID][i].setSensorState(state)

    def setStationsSignals(self, trackID, stateList):
        if trackID is None or stateList is None: return
        if trackID in self.stations.keys() and len(stateList) <= len(self.stations[trackID]):
            for i, state in enumerate(stateList):
                self.stations[trackID][i].setSignalState(state)
