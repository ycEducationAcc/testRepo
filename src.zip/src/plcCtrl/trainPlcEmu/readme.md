# Railway Trains Sensor-Power System Control PLC Simulator

### Introduction 

**Please refer to the Railway Trains Sensor-Power System Control PLC Simulator Readme file in the document fold with the below section: ** 

- Introduction
- Program design 
- Program Setup steps
- Execute the program
- Problem and solution

**Click below link to jump to the  readme file:** 

[Railway Trains Sensor-Power System Control PLC Simulator Readme file ](../../doc/trainsPlcSimu_readme.md)



------

> last edit by LiuYuancheng (liu_yuan_cheng@hotmail.com) by 26/07/2023 if you have any problem, please send me a message. 