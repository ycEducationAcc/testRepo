#!/usr/bin/python
#-----------------------------------------------------------------------------
# Name:        plcSignalSimulator.py
#
# Purpose:     A simple plc simulation module to connect and control the real-world 
#              emulator via UDP (to simulate the eletrical signals change) and handle
#              SCADA system Modbus TCP request.
#              This module will simulate the sensors-signals-auto-control system. 
# 
# Author:      Yuancheng Liu
#
# Created:     2023/05/29
# Version:     v0.1.2
# Copyright:   Copyright (c) 2023 Singapore National Cybersecurity R&D Lab LiuYuancheng
# License:     MIT License
#-----------------------------------------------------------------------------
""" 
Program design:
    We want to create a PLC simulator which can simulate a PLC set (Master[slot-0], 
    Slave[slot-1], Slave[slot-2]) with thress 16-in 8-out PLCs. The PLC sets will
    take 39 input signal and provide 19 output signal.
"""
from collections import OrderedDict

import plcSimGlobalBlock as gv
import modbusTcpCom
import plcSimulator

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class tFlipFlopLadderLogic(modbusTcpCom.ladderLogic):
    """ A T-flip-flop latching relay ladder logic set with 19 ladders. The ladder logic
        needs to be init and passed in the data handler (with handler auto-update flag 
        set to True).
    """

    def __init__(self, parent, ladderName) -> None:
        super().__init__(parent, ladderName=ladderName)

    def initLadderInfo(self):
        self.holdingRegsInfo['address'] = 0
        self.holdingRegsInfo['offset'] = 30
        self.srcCoilsInfo['address'] = 0
        self.srcCoilsInfo['offset'] = 15
        self.destCoilsInfo['address'] = 0
        self.destCoilsInfo['offset'] = 15
        # Init the flipflop coils and registers config:
        # For total 39 holding registers connected addresses
        # address: 0 - 12: weline sensors
        # address: 13 - 18: nsline sensors
        # address: 19 - 29: ccline sensors.
        # init all the flip flop maping table.
        self.ffConfig = [
            # Init all the weline signals flipflop:
            {'coilIdx': 0, 'onRegIdx':(0,), 'offRegIdx':(1,)},
            {'coilIdx': 1, 'onRegIdx':(2,), 'offRegIdx':(3,)},
            {'coilIdx': 2, 'onRegIdx':(4,), 'offRegIdx':(5,)},
            {'coilIdx': 3, 'onRegIdx':(6,), 'offRegIdx':(7,)},
            {'coilIdx': 4, 'onRegIdx':(8,), 'offRegIdx':(9,)},
            {'coilIdx': 5, 'onRegIdx':(10,), 'offRegIdx':(11,)},
            # Init all the nsline signals flipflop:
            {'coilIdx': 6, 'onRegIdx':(12,), 'offRegIdx':(13,)},
            {'coilIdx': 7, 'onRegIdx':(14,), 'offRegIdx':(15,)},
            {'coilIdx': 8, 'onRegIdx':(16,), 'offRegIdx':(17,)},
            # Init all the ccline signal flipflop:
            {'coilIdx': 9, 'onRegIdx':(18,), 'offRegIdx':(19,)},
            {'coilIdx': 10, 'onRegIdx':(20,), 'offRegIdx':(21,)},
            {'coilIdx': 11, 'onRegIdx':(22,), 'offRegIdx':(23,)},
            {'coilIdx': 12, 'onRegIdx':(24,), 'offRegIdx':(25,)},
            {'coilIdx': 13, 'onRegIdx':(26,), 'offRegIdx':(27,)},
            {'coilIdx': 14, 'onRegIdx':(28,), 'offRegIdx':(29,)},
        ]

#-----------------------------------------------------------------------------
    def _tfligFlogRun(self, coilState, toggleOnList, toggleOffList):
        """ Function to simulate a normal t-flip-flop latching replay to take input
            and calculate the output based on the current state. If there is N register
            state changed, this ladder logic will execute N times.
            Args:
                coilState (int/bool): Current output State. 
                toggleOnList (list(int/bool)): input registers's state list which can toggle
                    the relay on.
                toggleOffList (list(int/bool)): input registers's state list which can toggle
                    the relay off.
            Returns:
                bool: the filp-flop positive output.
        """
        if coilState: 
            if 1 in toggleOffList or True in toggleOffList: return False 
        else:
            if 1 in toggleOnList or True in toggleOnList: return True
        return coilState

#-----------------------------------------------------------------------------
    def runLadderLogic(self, regsList, coilList=None):
        coilsRsl = []
        if len(regsList) != 30 or coilList is None or len(coilList)!=15:
            gv.gDebugPrint('runLadderLogic(): input not valid', logType=gv.LOG_WARN)
            gv.gDebugPrint("Input registers list: %s" %str(regsList), logType=gv.LOG_INFO)
            gv.gDebugPrint("Input coils list: %s" %str(coilList), logType=gv.LOG_INFO)
        else:
            for item in self.ffConfig:
               coilState = coilList[item['coilIdx']]
               onRegListState = [regsList[i] for i in item['onRegIdx']]
               offRegListState = [regsList[i] for i in item['offRegIdx']]
               coilsRsl.append(self._tfligFlogRun(coilState, onRegListState, offRegListState) ) 
        gv.gDebugPrint('Finished calculate all coils: %s' %str(coilsRsl), logType=gv.LOG_INFO)
        return coilsRsl
        
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
class signalPlcSet(plcSimulator.plcSimuInterface):

    def __init__(self, parent, plcID, addressInfoDict, ladderObj, updateInt=0.6):
        super().__init__(parent, plcID, addressInfoDict, ladderObj, updateInt=updateInt)

    def _initInputState(self):
        self.regsAddrs = (0, 30)
        self.regSRWfetchKey = 'blockSensors'
        self.regs2RWmap = OrderedDict()
        self.regs2RWmap['weline'] = (0, 12)
        self.regs2RWmap['nsline'] = (12, 18)
        self.regs2RWmap['ccline'] = (18, 30)
        self.regsStateRW = OrderedDict()
        self.regsStateRW['weline'] = [0]*12
        self.regsStateRW['nsline'] = [0]*6
        self.regsStateRW['ccline'] = [0]*12

    def _initCoilState(self):
        self.coilsAddrs = (0, 15)
        self.coilsRWSetKey = 'blockSignals'
        self.coils2RWMap = OrderedDict()
        self.coils2RWMap['weline'] = (0, 6)
        self.coils2RWMap['nsline'] = (6, 9)
        self.coils2RWMap['ccline'] = (9, 15)
        self.coilStateRW = OrderedDict()
        self.coilStateRW['weline']  = [False]*6
        self.coilStateRW['nsline']  = [False]*3 
        self.coilStateRW['ccline']  = [False]*6 

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
def main():
    #gv.gDebugPrint("Start Init the PLC: %s" %str(gv.PLC_NAME), logType=gv.LOG_INFO)``
    gv.iLadderLogic = tFlipFlopLadderLogic(None, ladderName='T_flipflop_logic_set')
    addressInfoDict = {
        'hostaddress': gv.gModBusIP,
        'realworld':gv.gRealWorldIP, 
        'allowread':gv.ALLOW_R_L,
        'allowwrite': gv.ALLOW_W_L
    }
    plc = signalPlcSet(None, gv.PLC_NAME, addressInfoDict,  
                       gv.iLadderLogic, updateInt=gv.gInterval)
    plc.run()

if __name__ == "__main__":
    main()