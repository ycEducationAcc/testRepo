# 2D Railway[Metro] System Real-world Emulator

### Introduction 

**Please refer to the 2D Railway[Metro] System Real-world Emulator Readme file in the document fold with the below section: ** 

- Introduction
- Program design 
- Program Setup steps
- Execute the program
- Problem and solution

**Click below link to jump to the  readme file:** 

[ 2D Railway[Metro] System Real-world Emulator Readme file ](../../doc/metroEmuUI_readme.md)



------

> last edit by LiuYuancheng (liu_yuan_cheng@hotmail.com) by 25/07/2023 if you have any problem, please send me a message. 